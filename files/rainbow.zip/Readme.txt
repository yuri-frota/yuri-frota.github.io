About the solution's files

1- For each file in the set of instances, one file with the same name plus the extension ".sol" was created.
2- The solution file (with extension ".sol") has the following structure:
    2.1-The number of non-trivial cycles is shown by the line:
		Number of cycles: [integer representing the number of non-trivial cycles]
      	each cycle begins with the line:
		Cycle [integer representing the cycle index]
      	then, there will be as many lines as the number of edges in the cycle with the following format:
		[vertex] [vertex] [color]
      	indicating the extreme vertices and the color of the edge according to the file of the instance.
    2.2-The number of trivial cycles is shown by the line:
		Isolated vertices: [integer representing the number of trivial cycles]
	then, all isolated vertices separated by space are shown.
    2.3-The total number of rainbow cycles is shown by the line:
		Solution: [integer representing the total number of rainbow cycles]

